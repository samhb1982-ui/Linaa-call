# Linaa Call — Android V2 Alpha

This is the first native Android receiver for the one-phone Linaa project.

## What works
- Native Android app shell
- Android microphone permission
- WebRTC audio through PeerJS
- Receiver ID shown in the app
- Incoming call screen inside the app
- Answer / reject / hang up
- Remote audio playback
- Uses PeerJS Cloud only for signaling; the voice stream is WebRTC

## Important limitation of V2 alpha
The app currently needs to be open for incoming-call testing.

That is intentional: Android 14/15 impose restrictions around background microphone
foreground services. The next stage will use a proper VoIP-style wake-up path and
native incoming-call UI.

## Build
Open this folder in Android Studio and let Gradle sync.

Requirements:
- Android Studio with Android SDK 35
- JDK 17 or newer
- Android phone running Android 8+ (your Android 15 phone is suitable)

Then:
1. Enable Developer Options + USB debugging on the phone.
2. Connect the phone.
3. Run the `app` configuration.
4. Grant microphone permission.

## Testing the receiver with one phone
For this alpha, the AI caller does not exist yet. A second browser/device can act
as the temporary caller by creating a PeerJS connection and calling the receiver ID.

The architecture after this test is:

AI voice engine
    ↓
WebRTC caller
    ↓
Internet
    ↓
Linaa Android receiver
    ↓
phone speaker + microphone

The next implementation stage is to remove the temporary browser caller and build
the actual AI caller service.
