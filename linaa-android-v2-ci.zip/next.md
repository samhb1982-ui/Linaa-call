# Next build stage

1. Add persistent device registration.
2. Add push wake-up for a call request.
3. Show a native incoming-call screen when the app is backgrounded.
4. Establish WebRTC audio after Answer.
5. Build the AI caller:
   - speech-to-text
   - LLM conversation
   - text-to-speech
   - WebRTC audio
   - interruption / barge-in handling
6. Add scheduled calls/reminders.

Do not treat this alpha as the final background-call implementation.
