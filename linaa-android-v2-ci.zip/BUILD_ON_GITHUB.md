# Build Linaa.apk without Android Studio

1. Create a GitHub repository (a free repository is enough).
2. Upload the contents of this folder to the repository.
3. Open **Actions**.
4. Select **Build Linaa APK**.
5. Press **Run workflow** (or push to `main`).
6. When the run finishes, open the workflow run and download the **Linaa-debug-apk** artifact.
7. Extract the artifact and install `app-debug.apk` on the Infinix.

The workflow uses Java 17, Gradle, and the Android build system. It produces a
debug-signed APK suitable for testing on the phone.

This does not yet make background calls work. It builds the V2 alpha receiver
so we can test the WebRTC audio path first.
